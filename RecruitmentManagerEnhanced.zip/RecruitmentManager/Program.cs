
using RecruitmentManager.Core;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Recruitment Manager Initialized with GUI and Mock Interviews.");
    }
}
